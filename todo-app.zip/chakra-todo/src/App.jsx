import { Button, Modal, ModalOverlay, ModalContent, ModalHeader, ModalFooter, ModalBody, ModalCloseButton, Input } from "@chakra-ui/react";
import { useState } from "react";
import TodoList from "./components/TodoList";
import TodoForm from "./components/TodoForm";
import SearchTodo from "./components/SearchTodo";
import FilterTodo from "./components/FilterTodo";
import ColorModeSwitcher from "./components/ColorModeSwitcher";
import { useTodos } from "./hooks/useTodos";
import { useTodo } from "./hooks/useTodo";
import "./css/App.css";

function App() {
  const { todos, addTodo, setSearchQuery, searchQuery, setTodos } = useTodos();
  const {
    confirmDeleteTodo,
    deleteTodo,
    confirmEditTodo,
    editTodo,
    toggleCheckTodo,
    isDeleteOpen,
    onDeleteClose,
    isEditOpen,
    onEditClose,
    editText,
    setEditText,
  } = useTodo(setTodos);

  const [filter, setFilter] = useState('all');

  const filteredTodos = todos.filter((todo) => {
    if (filter === 'checked') return todo.completed;
    if (filter === 'unchecked') return !todo.completed;
    return true;
  });

  return (
    <div className="todo-wrapp">
      <div className="container">
        <div className="top">
          <h1>Todo List</h1>
          <ColorModeSwitcher />
        </div>
        <div className="search-add-wrapp">
          <div>
            <SearchTodo searchQuery={searchQuery} setSearchQuery={setSearchQuery} />
          </div>
          <div>
            <FilterTodo filter={filter} setFilter={setFilter} />
          </div>
          <div>
            <TodoForm addTodo={addTodo} />
          </div>
        </div>
        <br />
        <TodoList todos={filteredTodos} confirmDeleteTodo={confirmDeleteTodo} confirmEditTodo={confirmEditTodo} toggleCheckTodo={toggleCheckTodo} />

        <Modal isOpen={isDeleteOpen} onClose={onDeleteClose}>
          <ModalOverlay />
          <ModalContent>
            <ModalHeader>Confirm Delete</ModalHeader>
            <ModalCloseButton />
            <ModalBody>
              Do you want to remove this from your todo list?
            </ModalBody>
            <ModalFooter>
              <Button colorScheme="blue" mr={3} onClick={onDeleteClose}>
                No
              </Button>
              <Button colorScheme="red" onClick={deleteTodo}>
                Yes
              </Button>
            </ModalFooter>
          </ModalContent>
        </Modal>

        <Modal isOpen={isEditOpen} onClose={onEditClose}>
          <ModalOverlay />
          <ModalContent>
            <ModalHeader>Edit Todo</ModalHeader>
            <ModalCloseButton />
            <ModalBody>
              <Input
                value={editText}
                onChange={(e) => setEditText(e.target.value)}
                placeholder="Edit todo..."
                _placeholder={{ color: "gray.500" }}
                focusBorderColor="teal.400"
              />
            </ModalBody>
            <ModalFooter>
              <Button colorScheme="blue" mr={3} onClick={onEditClose}>
                Cancel
              </Button>
              <Button colorScheme="teal" onClick={editTodo}>
                Save
              </Button>
            </ModalFooter>
          </ModalContent>
        </Modal>
      </div>
    </div>
  );
}

export default App;