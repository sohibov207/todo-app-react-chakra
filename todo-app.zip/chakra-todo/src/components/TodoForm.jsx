import { useState } from "react";
import { Input, Button, Flex, Modal, ModalOverlay, ModalContent, ModalHeader, ModalFooter, ModalBody, ModalCloseButton, useDisclosure } from "@chakra-ui/react";

function TodoForm({ addTodo }) {
  const [text, setText] = useState("");
  const { isOpen, onOpen, onClose } = useDisclosure();

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!text.trim()) return;
    addTodo(text);
    setText("");
    onClose();
  };

  return (
    <>
      <Button colorScheme="teal" onClick={onOpen}>
      <div className="button-text">
        <i className="fa-solid fa-square-plus"></i>
        <span>Add</span>
      </div>
      </Button>

      <Modal isOpen={isOpen} onClose={onClose}>
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>Create New Todo</ModalHeader>
          <ModalCloseButton />
          <ModalBody>
            <form onSubmit={handleSubmit}>
              <Flex gap={2} direction="column">
                <Input
                  color="teal"
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  placeholder="New todo..."
                  _placeholder={{ color: "gray.500" }}
                  focusBorderColor="teal.400"
                />
              </Flex>
            </form>
          </ModalBody>

          <ModalFooter>
            <Button colorScheme="teal" mr={3} onClick={handleSubmit}>
              Create
            </Button>
            <Button variant="ghost" onClick={onClose}>Cancel</Button>
          </ModalFooter>
        </ModalContent>
      </Modal>
    </>
  );
}

export default TodoForm;