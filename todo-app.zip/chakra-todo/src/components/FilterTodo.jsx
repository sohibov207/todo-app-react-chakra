import React from 'react';
import { Button, ButtonGroup } from '@chakra-ui/react';

function FilterTodo({ filter, setFilter }) {
  return (
    <ButtonGroup variant="outline" spacing="6">
      <Button colorScheme={filter === 'all' ? 'teal' : 'gray'} onClick={() => setFilter('all')}>All</Button>
      <Button colorScheme={filter === 'checked' ? 'teal' : 'gray'} onClick={() => setFilter('checked')}>Checked</Button>
      <Button colorScheme={filter === 'unchecked' ? 'teal' : 'gray'} onClick={() => setFilter('unchecked')}>Unchecked</Button>
    </ButtonGroup>
  );
}

export default FilterTodo;