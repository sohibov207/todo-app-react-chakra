import React from 'react';
import { Button } from '@chakra-ui/react';

function TodoList({ todos, confirmDeleteTodo, confirmEditTodo, toggleCheckTodo }) {
  return (
    <ul className="todo-item-wrapp">
      {todos.map((todo) => (
        <li className="todo" key={todo.id}>
          <span>{todo.todo}</span>
          <div className="button">
            <Button colorScheme={todo.completed ? 'blue' : 'green'} onClick={() => toggleCheckTodo(todo.id)}>
              {todo.completed ? 'Uncheck' : 'Check'}
            </Button>
            <Button colorScheme='red' onClick={() => confirmDeleteTodo(todo.id)}><i className="fa-solid fa-trash-can"></i></Button>
            <Button colorScheme='teal' onClick={() => confirmEditTodo(todo)}><i className="fa-solid fa-pencil"></i></Button>
          </div>
        </li>
      ))}
    </ul>
  );
}

export default TodoList;