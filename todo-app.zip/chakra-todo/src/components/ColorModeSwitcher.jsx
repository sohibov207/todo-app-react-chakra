import { IconButton, useColorMode, useToast } from "@chakra-ui/react";
import { useEffect } from "react";

const ColorModeSwitcher = (props) => {
  const { colorMode, toggleColorMode } = useColorMode();
  const toast = useToast();

  useEffect(() => {
    toast({
      title: "Did you know?",
      description: "You can change color mode by clicking just a button",
      status: "error",
      duration: 2000,
      isClosable: false,
      position: "top",
      variant: "solid",
      containerStyle: {
        color: "white",
      },
    });
  }, [toast]);

  const iconClass = colorMode === "light" ? "fa-solid fa-moon" : "fa-solid fa-sun";

  return (
    <div className="color-switcher">
      <IconButton
        textAlign="center"
        size="md"
        fontSize="lg"
        variant="ghost"
        color="current"
        marginLeft="2"
        onClick={toggleColorMode}
        icon={<i className={iconClass} />}
        aria-label={`Switch to ${colorMode === "light" ? "dark" : "light"} mode`}
        {...props}
      />
    </div>
  );
};

export default ColorModeSwitcher;