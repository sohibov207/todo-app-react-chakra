import React from 'react';
import { Input, InputGroup, InputLeftElement } from '@chakra-ui/react';

function FilterTodo({ searchQuery, setSearchQuery }) {
  return (
    <InputGroup>
      <InputLeftElement pointerEvents="none">
      <i className="fa-solid fa-magnifying-glass"></i>
      </InputLeftElement>
      <Input
        type="text"
        placeholder="Search todos..."
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
        focusBorderColor="teal.400"
      />
    </InputGroup>
  );
}

export default FilterTodo;