import { useState, useEffect } from 'react';

const API_URL = "https://dummyjson.com/todos";

export const useTodos = () => {
  const [todos, setTodos] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    fetch(API_URL)
      .then((res) => res.json())
      .then((data) => setTodos(data.todos));
  }, []);

  const addTodo = (todoText) => {
    fetch(`${API_URL}/add`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ todo: todoText, completed: false, userId: 1 }),
    })
      .then((res) => res.json())
      .then((newTodo) => setTodos([...todos, newTodo]));
  };

  const filteredTodos = todos.filter((todo) =>
    todo.todo.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return {
    todos: filteredTodos,
    addTodo,
    setSearchQuery,
    searchQuery,
    setTodos,
  };
};