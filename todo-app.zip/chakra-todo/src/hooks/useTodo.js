import { useState } from 'react';
import { useDisclosure } from '@chakra-ui/react';

const API_URL = "https://dummyjson.com/todos";

export const useTodo = (setTodos) => {
  const [todoToDelete, setTodoToDelete] = useState(null);
  const [todoToEdit, setTodoToEdit] = useState(null);
  const [editText, setEditText] = useState("");
  const { isOpen: isDeleteOpen, onOpen: onDeleteOpen, onClose: onDeleteClose } = useDisclosure();
  const { isOpen: isEditOpen, onOpen: onEditOpen, onClose: onEditClose } = useDisclosure();

  const confirmDeleteTodo = (id) => {
    setTodoToDelete(id);
    onDeleteOpen();
  };

  const deleteTodo = () => {
    fetch(`${API_URL}/${todoToDelete}`, { method: "DELETE" }).then(() => {
      setTodos((prevTodos) => prevTodos.filter((todo) => todo.id !== todoToDelete));
      setTodoToDelete(null);
      onDeleteClose();
    });
  };

  const confirmEditTodo = (todo) => {
    setTodoToEdit(todo);
    setEditText(todo.todo);
    onEditOpen();
  };

  const editTodo = () => {
    fetch(`${API_URL}/${todoToEdit.id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ todo: editText }),
    })
      .then((res) => res.json())
      .then((updatedTodo) => {
        setTodos((prevTodos) => prevTodos.map((todo) => (todo.id === todoToEdit.id ? updatedTodo : todo)));
        setTodoToEdit(null);
        setEditText("");
        onEditClose();
      });
  };

  const toggleCheckTodo = (id) => {
    setTodos((prevTodos) => prevTodos.map((todo) => 
      todo.id === id ? { ...todo, completed: !todo.completed } : todo
    ));
  };

  return {
    confirmDeleteTodo,
    deleteTodo,
    confirmEditTodo,
    editTodo,
    toggleCheckTodo,
    isDeleteOpen,
    onDeleteClose,
    isEditOpen,
    onEditClose,
    editText,
    setEditText,
  };
};